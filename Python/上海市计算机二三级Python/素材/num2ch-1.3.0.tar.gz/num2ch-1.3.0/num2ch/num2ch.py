# -*- coding: utf-8 -*-
import re


class Num2CN:
    def __init__(self, debug=False):
        self.number2character = {
            1: "一",
            2: "二",
            3: "三",
            4: "四",
            5: "五",
            6: "六",
            7: "七",
            8: "八",
            9: "九",
            0: "零",

        }
        self.digit2character = {
            1: "一",
            2: "二",
            3: "三",
            4: "四",
            5: "五",
            6: "六",
            7: "七",
            8: "八",
            9: "九",
            0: "零",
            ".": "点",

        }
        ### EMAIL PATTERN ###
        self.email_pattern = re.compile(
            r"(\w+(?:[\.-]?\w+)*@\w+(?:[\.-]?\w+)*(?:\.\w{2,3})+)"
        )
        ### URL PATTERN ###
        self.url_pattern = re.compile(
            r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"
        )
        ### SEPARATOR ###
        # self.pattern_separator = re.compile('[\:\：、,，。\？\?\!\！]')
        self.pattern_separator = re.compile(r"[\:\：；、。\？\?\!\！]")
        ### REMOVE ###
        self.pattern_remove = re.compile(r"[\(\（][^\)\(\）\）]+[\)\）]")
        ### SPACE REDUCTION ###
        self.pattern_space_reduction = re.compile("(  )[ ]*")
        ### General number ###
        self.pattern_number = re.compile(r"(\-)?\s*([0-9]+)(\.*)([0-9]*)")
        ### General countable ###
        self.pattern_countable = re.compile(
            r"(\-*\s*[0-9]+\.*[0-9]*)\s*(多)*\s*(种|人|国|家|周|码|个|位|条|只|匹|头|条|峰|颗|根|张|片|棵|株|朵|顿|道|块|粒|盘|把|台|坨|件|顶|枚|座|栋|面|扇|间|堵|辆|列|架|艘|方|支|封|则|首|篇|幅|发|门|轮|阵|场|匹|回|尾|阙|网|炮|丘|袭|辆|挑|担|壳|窠|曲|墙|群|腔|砣|客|贯|扎|捆|刀|令|打|手|罗|坡|山|岭|江|溪|钟|队|单|双|对|出|口|头|脚|板|跳|枝|贴|针|线|管|名|身|堂|课|本|页|丝|毫|厘|分|钱|两|斤|担|铢|石|钧|锱|忽|毫|厘|分|寸|尺|丈|里|寻|常|铺|程|撮|勺|合|升|斗|盘|碗|碟|迭|桶|笼|盆|盒|杯|钟|斛|锅|簋|篮|盘|桶|罐|瓶|壶|卮|盏|箩|箱|煲|啖|袋|钵|年|月|日|季|刻|时|周|天|秒|分|旬|纪|岁|世|更|夜|春|夏|秋|冬|代|伏|辈|丸|泡|粒|颗|幢|堆|届)*\s*(\-|~)?\s*(\-*\s*[0-9]+\.*[0-9]*)?\s*(多)*\s*(种|人|国|家|周|码|个|位|条|只|匹|头|条|峰|颗|根|张|片|棵|株|朵|顿|道|块|粒|盘|把|台|坨|件|顶|枚|座|栋|面|扇|间|堵|辆|列|架|艘|方|支|封|则|首|篇|幅|发|门|轮|阵|场|匹|回|尾|阙|网|炮|丘|袭|辆|挑|担|壳|窠|曲|墙|群|腔|砣|客|贯|扎|捆|刀|令|打|手|罗|坡|山|岭|江|溪|钟|队|单|双|对|出|口|头|脚|板|跳|枝|贴|针|线|管|名|身|堂|课|本|页|丝|毫|厘|分|钱|两|斤|担|铢|石|钧|锱|忽|毫|厘|分|寸|尺|丈|里|寻|常|铺|程|撮|勺|合|升|斗|盘|碗|碟|迭|桶|笼|盆|盒|杯|钟|斛|锅|簋|篮|盘|桶|罐|瓶|壶|卮|盏|箩|箱|煲|啖|袋|钵|年|月|日|季|刻|时|周|天|秒|分|旬|纪|岁|世|更|夜|春|夏|秋|冬|代|伏|辈|丸|泡|粒|颗|幢|堆|届)"
        )
        ### Currency ###
        self.pattern_currency = re.compile(
            r"(\$|€|¥|£|美金|美元|美圆|日圆|日元|台币|新台币|台币|欧元|英镑|泰铢|披索|马币|加币|新加坡币)\s*(\-*\s*[0-9]+\.*[0-9]*)(\s*[-~～到]\s*)?(\$|€|¥|£|美金|美元|美圆|日圆|日元|台币|新台币|台币|欧元|英镑|泰铢|披索|马币|加币|新加坡币)?(\-*\s*[0-9]+\.*[0-9]*)?"
        )
        self.pattern_currency2 = re.compile(
            r"(\-*\s*[0-9]+\.*[0-9]*)(元|圆|美金|美元|美圆|日圆|日元|台币|新台币|台币|欧元|英镑|泰铢|披索|马币|加币|新加坡币)?(\s*[-~～到]\s*)?(\-*\s*[0-9]+\.*[0-9]*)?\s*(元|圆|美金|美元|美圆|日圆|日元|台币|新台币|台币|欧元|英镑|泰铢|披索|马币|加币|新加坡币)"
        )
        ### SERIAL NUMBER ###
        self.pattern_serial = re.compile(r"(?<!\d)([\d\.]*[\d]+)(?!\d)")
        ### ###
        self.debug = debug

    def full_to_half(self, text):
        """
        Convert full-width character to half-width one.
        """

        def convert(char):
            num = ord(char)
            if num == 0x3000:  # space
                num = 32
            elif num == 0x3001:  # comma
                num = 44
            elif num == 0x3002:  # full stop
                num = 46
            elif num == 0xFF03:  # full hashtag ＃
                num = 35
            elif 0xFF01 <= num <= 0xFF5E:  # full width digits and alphabets
                num -= 0xFEE0
            elif 0x3008 <= num <= 0x301B:  # parentheses
                num = 40 if (num & 1) == 0 else 41
            return chr(num)

        return "".join(map(convert, text))

    def clean(self, text):
        text = self.pattern_remove.sub("", text)
        text = self.pattern_separator.sub(" ` ", text)
        text = self.full_to_half(text).lower()  # 会把全角句号变成小数点
        return text

    def _to_thousand(self, number, has_larger_part, is_last_zero):
        assert isinstance(number, int)
        assert number < 10000
        # if number == 0 and add_zero:
        #     return self.number2character[0]
        # elif number == 0 and not add_zero:
        #     return ""
        if number == 0:
            return ""
        result = ""

        thousand, remainder = divmod(number, 1000)
        is_zero = True if thousand == 0 else False
        condition = has_larger_part and is_last_zero and not is_zero
        if condition:
            result += self.number2character[0] + self.number2character[thousand] + "千"
        elif not is_zero:
            result += self.number2character[thousand] + "千"
        if self.debug:
            print(
                "[INFO] thousand: {}, remainder: {}, is_zero: {}, has_larger_part: {}, is_last_zero:{}".format(
                    thousand, remainder, is_zero, has_larger_part, is_last_zero
                )
            )
        has_larger_part = has_larger_part or not is_zero  # 更大的数值：要嘛前面已经有，要么现在数字就是
        is_last_zero = is_zero

        hundred, remainder = divmod(remainder, 100)
        is_zero = True if hundred == 0 else False
        condition = has_larger_part and is_last_zero and not is_zero
        if condition:
            result += self.number2character[0] + self.number2character[hundred] + "百"
            # add_zero = True
        elif not is_zero:
            result += self.number2character[hundred] + "百"
        if self.debug:
            print(
                "[INFO] hundred: {}, remainder: {}, is_zero: {}, has_larger_part: {}, is_last_zero:{}".format(
                    hundred, remainder, is_zero, has_larger_part, is_last_zero
                )
            )
        has_larger_part = has_larger_part or not is_zero  # 更大的数值：要嘛前面已经有，要么现在数字就是
        is_last_zero = is_zero

        ten, digit = divmod(remainder, 10)
        is_zero = True if ten == 0 else False
        condition = has_larger_part and is_last_zero and not is_zero
        if ten == 1 and not has_larger_part:
            ten_char = ""
        elif ten == 2:
            ten_char = self.digit2character[ten]
        else:
            ten_char = self.number2character[ten]
        # ten_char="" if ten==1 and not has_larger_part else self.number2character[ten]
        if condition:
            result += self.number2character[0] + ten_char + "十"
        elif not is_zero:
            result += ten_char + "十"
        if self.debug:
            print(
                "[INFO] ten: {}, digit: {}, is_zero: {}, has_larger_part: {}, is_last_zero:{}".format(
                    ten, digit, is_zero, has_larger_part, is_last_zero
                )
            )
        has_larger_part = has_larger_part or not is_zero  # 更大的数值：要嘛前面已经有，要么现在数字就是
        is_last_zero = is_zero

        is_zero = True if digit == 0 else False
        condition = has_larger_part and is_last_zero and not is_zero
        if digit == 2:
            if has_larger_part:
                digit_char = self.digit2character[digit]
            else:
                digit_char = self.number2character[digit]
        else:
            digit_char = self.number2character[digit]
        if condition:
            result += self.number2character[0] + digit_char
        elif not is_zero:
            result += digit_char
        if self.debug:
            print(
                "[INFO] digit: {}, , is_zero: {}, has_larger_part: {}, is_last_zero:{}".format(
                    digit, is_zero, has_larger_part, is_last_zero
                )
            )
        return result

    def normalize_email(self, text):
        assert isinstance(text, str)
        if len(text) == 0:
            return ""
        nrm_text = self.email_pattern.sub("", text)
        return nrm_text

    def normalize_url(self, text):
        assert isinstance(text, str)
        if len(text) == 0:
            return ""
        nrm_text = self.url_pattern.sub("", text)
        return nrm_text

    def cur2han(self, unit, num):
        unit = unit or ""
        num = num or ""
        if unit == "€":
            return "{}欧元".format(num)
        elif unit == "$":
            return "{}美元".format(num)
        elif unit == "¥":
            return "人民币{}元".format(num)
        elif unit == "£":
            return "{}英镑".format(num)
        else:
            return "{}{}".format(num, unit)

    def normalize_number(self, text):
        """normalize (countable) number, including integer and float."""
        assert isinstance(text, str)
        if len(text) == 0:
            return ""
        nrm_text = text
        for item in reversed(list(self.pattern_number.finditer(nrm_text))):
            start_idx, end_idx = item.span()
            minus, integer, dot, digit = item.groups()
            integer = self.normalize_int(integer) if integer is not None else None
            digit = self.normalize_digit(digit) if digit is not None else None
            #minus = "负" if minus is not None else ""
            minus = "负" if minus =="-" else ""
            print(minus, integer, dot, digit)
            if dot != "":
                nrm_text = (
                    nrm_text[:start_idx]
                    + minus
                    + "{}点{}".format(integer, digit)
                    + nrm_text[end_idx:]
                )
            else:
                nrm_text = (
                    nrm_text[:start_idx]
                    + minus
                    + "{}".format(integer)
                    + nrm_text[end_idx:]
                )
        return nrm_text

    def normalize_currency(self, text):
        """Convert text to currency

        Example
                        2019  2019
                        $ 2019 二千零一十九元
                        $12345678 一千二百三十四万五千六百七十八元
                        €980000301  九亿八千万零三百零一欧元
        """
        assert isinstance(text, str)
        if len(text) == 0:
            return ""
        nrm_text = text
        ### 单位在前方 ###
        for item in reversed(list(self.pattern_currency.finditer(nrm_text))):
            start_idx, end_idx = item.span()
            unit1 = item.groups()[0]
            num1 = self.normalize_number(item.groups()[1])
            num1 = self.cur2han(unit1, num1)

            fromto = "到" if item.groups()[2] is not None else ""

            num2 = (
                self.normalize_number(item.groups()[4])
                if item.groups()[4] is not None
                else None
            )
            unit2 = item.groups()[3] or unit1 if num2 is not None else ""
            num2 = self.cur2han(unit2, num2)
            full = num1 + fromto + num2

            nrm_text = nrm_text[:start_idx] + full + nrm_text[end_idx:]

        ### 单位在后方 ###
        for item in reversed(list(self.pattern_currency2.finditer(nrm_text))):
            start_idx, end_idx = item.span()
            num1 = self.normalize_number(item.groups()[0])
            unit1 = item.groups()[1] or item.groups()[4]
            num1 = self.cur2han(unit1, num1)

            fromto = "到" if item.groups()[2] is not None else ""

            num2 = (
                self.normalize_number(item.groups()[3])
                if item.groups()[3] is not None
                else None
            )
            unit2 = item.groups()[4] if num2 is not None else ""
            num2 = self.cur2han(unit2, num2)
            full = num1 + fromto + num2

            nrm_text = nrm_text[:start_idx] + full + nrm_text[end_idx:]
        return nrm_text

    def normalize_int(self, text):
        assert isinstance(text, str)
        try:
            number = int(text)
        except ValueError:
            print("{} cannot be converted to number.".format(text))
            raise
        if number >= 1000000000000000:  # 万兆
            print("{} is greater than what we can convert to Chinese.".format(number))
            return text
        if number == 0:
            return self.number2character[number]

        zhao, remainder = divmod(number, 1000000000000)
        has_larger_part = False
        is_last_zero = False
        zhao = (
            self._to_thousand(zhao, has_larger_part, is_last_zero) + "兆"
            if zhao > 0
            else ""
        )
        is_zero = True if zhao == "" else False
        has_larger_part = has_larger_part or not is_zero  # 更大的数值：要么前面已经有，要么现在数字就是
        is_last_zero = is_zero

        yi, remainder = divmod(remainder, 100000000)
        yi = (
            self._to_thousand(yi, has_larger_part, is_last_zero) + "亿" if yi > 0 else ""
        )
        is_zero = True if yi == "" else False
        has_larger_part = has_larger_part or not is_zero  # 更大的数值：要么前面已经有，要么现在数字就是
        is_last_zero = is_zero

        wan, remainder = divmod(remainder, 10000)
        wan = (
            self._to_thousand(wan, has_larger_part, is_last_zero) + "万"
            if wan > 0
            else ""
        )
        is_zero = True if wan == "" else False
        has_larger_part = has_larger_part or not is_zero  # 更大的数值：要么前面已经有，要么现在数字就是
        is_last_zero = is_zero

        remainder = (
            self._to_thousand(remainder, has_larger_part, is_last_zero)
            if remainder > 0
            else ""
        )
        if self.debug:
            print(
                "zhao: {}, yi:{}, wan:{}, remainder:{}".format(zhao, yi, wan, remainder)
            )
        return zhao + yi + wan + remainder

    def normalize_digit(self, text):
        assert isinstance(text, str)
        if len(text) == 0:
            return ""
        # try:
        #     number = int(text)
        # except ValueError:
        #     print("{} cannot be converted to number.".format(text))
        #     raise
        normalized_text = ""
        for c in text:
            c = int(c) if c.isdigit() else c
            normalized_text += self.digit2character[c]
        return normalized_text

    def normalize_countable(self, text):
        assert isinstance(text, str)
        if len(text) == 0:
            return ""
        nrm_text = text

        for item in reversed(list(self.pattern_countable.finditer(nrm_text))):
            start_idx, end_idx = item.span()
            (
                num_left,
                more_left,
                unit_left,
                fromto,
                num_right,
                more_right,
                unit_right,
            ) = item.groups()
            num_left = self.normalize_number(num_left)
            more_left = more_left or ""
            more_right = more_right or ""
            fromto = "到" if fromto else ""
            unit_left = unit_left or ""
            unit_right = unit_right or ""
            num_right = self.normalize_number(num_right) if num_right else ""
            # if fromto=='':
            #     nrm_text = nrm_text[ : start_idx] + num_left + unit_left + num_right + unit_right + nrm_text[ end_idx: ]
            # elif unit_left=='':
            #     nrm_text = nrm_text[ : start_idx] + num_left + fromto + num_right + unit_right + nrm_text[ end_idx: ]
            # else:
            #     nrm_text = nrm_text[ : start_idx] + num_left + unit_left + fromto + num_right + unit_right + nrm_text[ end_idx: ]
            nrm_text = (
                nrm_text[:start_idx]
                + num_left
                + more_left
                + unit_left
                + fromto
                + num_right
                + more_right
                + unit_right
                + nrm_text[end_idx:]
            )
        return nrm_text

    def normalize_serial(self, text):
        assert isinstance(text, str)
        if len(text) == 0:
            return ""
        nrm_text = text
        for item in reversed(list(self.pattern_serial.finditer(nrm_text))):
            digit = item.groups()[0]
            digit = self.normalize_digit(digit) if digit is not None else None
            start_idx, end_idx = item.span()
            nrm_text = nrm_text[:start_idx] + "{}".format(digit) + nrm_text[end_idx:]
        return nrm_text

    def normalize(self, text, skip_url=True, skip_email=True):
        assert isinstance(text, str)
        text = text.strip()
        if skip_url:
            text = self.normalize_url(text)
        if skip_email:
            text = self.normalize_email(text)
        text = self.clean(text)
        text = self.normalize_currency(text)
        text = self.normalize_countable(text)
        text = self.normalize_serial(text)
        text = self.pattern_space_reduction.sub(" ", text)
        if text[0]=='-':
            text='负'+text[1:]
        return text


if __name__ == "__main__":
    n2c = Num2CN()
    #texts = ["$1.20", "20.0块", "12.121212个苹果", "20.02002只", "9.487", "0.80080123", "10.02根"]
    #texts = ["$120","200元","€21212","-9487","080080123","2002002支","1002根", "-0.80080123"]
    texts = ["-9487","-0.80080123"]
    for text in texts:
        print(text, " -> ", n2c.normalize(text))
