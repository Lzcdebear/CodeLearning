﻿# coding=utf-8
 
from setuptools import setup, find_packages
# python setup.py sdist 打包成tar.gz的形式
# python setup.py bdist_wheel  打包成wheel格式
 
setup(
    #py_modules=["num2ch.py"],   #需要打包的文件夹下的py文件名，可省略
    packages=["num2ch"],        #需要打包的目录列表,原为packages=find_packages()
    name="num2ch",           #包名称，也就是文件夹名称,在pip中显示的项目名称
    version="1.3.0",                 #包的版本
    description="数字转中文",  #对当前package的较短总结
    long_description="数字转中文",          #对当前package的详细说明
    author="dfli",                #作者姓名
    author_email="dfli@smmu.edu.cn", #作者邮箱
    url = 'https://pypi.python.org',
    #install_requires=['numpy'],      #第三方依赖,这些依赖包会在程序安装的时候也会安装
    zip_safe=False,                  #此项需要，否则卸载报windows error错误
    license="MIT Licence",           #支持的开源协议
    python_requires=">=3.4.0",       #指定python的安装要求
    include_package_data=True
 
)
 
